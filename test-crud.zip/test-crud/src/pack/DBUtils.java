package pack;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class DBUtils {
	public static PreparedStatement getPreparedStatement(String sql) throws ClassNotFoundException,SQLException{
	PreparedStatement ps = null;

		//Class.forName("com.mysql.jdbc.Driver");
		Class.forName("com.mysql.cj.jdbc.Driver");
		String url = "jdbc:mysql://localhost:3306/testdb";
		String user = "root";
		String pass = "root";
		
		Connection con = DriverManager.getConnection(url, user, pass);
		 ps = con.prepareStatement(sql);
		return ps;
	}
	/* public static void main(String[] args) throws ClassNotFoundException, SQLException{
		getPreparedStatement("select * from student");
		
	}*/

}