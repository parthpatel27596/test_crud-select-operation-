package dbop;
import model.Student;
import pack.DBUtils;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
public class DataAccess {
	public void addNew(Student n) throws ClassNotFoundException, SQLException {
		PreparedStatement ps = DBUtils.getPreparedStatement("insert into student values(?,?,?,?) ");
		
		ps.setInt(1, n.getId());
		ps.setString(2, n.getName());
		ps.setInt(3, n.getAge());
		ps.setString(4, n.getSchoolname());
		ps.executeUpdate();
	}
	
	public static List<Student> getAll(){
	List<Student> ls = new LinkedList<>();
	
		ResultSet rs;
		try {
			rs = DBUtils.getPreparedStatement("select * from student").executeQuery();
			while(rs.next())
			{
				Student n = new Student(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4));
				ls.add(n);
			}
		
	} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ls;
		
	}
		public static List<Student> getNewById(int id){
		List<Student> ls = new LinkedList<>();
		String url = "select * from student where id = " +id;
		
			ResultSet rs;
			try {
				rs = DBUtils.getPreparedStatement("select * from student").executeQuery();
				while(rs.next())
				{
					Student n = new Student(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4));
					ls.add(n);
				}
			
		} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return ls;
			
						
	}
		public void edit(int id,String name,int age,String schoolname) {
			String sql = "update student set name = ?,age = ?,schoolname = ?"+"where id = ?";
		
		PreparedStatement ps;
		try {
			ps = DBUtils.getPreparedStatement(sql);
			ps.setString(1,name);
			ps.setInt(2,age);
			ps.setString(3,schoolname);
			ps.executeUpdate();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		public void delete(int id) {
			String sql = "delete student where id = ?";
		
		PreparedStatement ps;
		try {
			ps = DBUtils.getPreparedStatement(sql);
			ps.setInt(1,id);
			ps.executeUpdate();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
}
